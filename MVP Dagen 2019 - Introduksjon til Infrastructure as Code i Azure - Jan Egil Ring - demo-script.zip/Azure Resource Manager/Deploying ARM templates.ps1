﻿$TemplateFile = '~\Git\PSDemo\Azure\ExportedTemplate-LBDemo\template.json'
$TemplateParameterFile = '~\Git\PSDemo\Azure\QuickStartDemo\parameters.json'

psedit $TemplateFile

Connect-AzAccount

Set-AzContext -Subscription "380d994a-1234-5678-ab8b-815e2ef18a2b"

# Option 1: Create resource manually, export template and customize
New-AzResourceGroup -Name ARMLBDemo -Location westeurope

New-AzResourceGroupDeployment -Name ARMLBDemo -ResourceGroupName ARMLBDemo `
    -TemplateFile $TemplateFile

# Clean up demo
Remove-AzResourceGroup -Name ARMLBDemo -Force


# Option 2: Quick Start template - Internal Load Balancer

psedit $TemplateParameterFile

New-AzResourceGroup -Name ARMLBDemoQuickStart -Location westeurope

New-AzResourceGroupDeployment -Name ARMLBDemoQuickStart  -ResourceGroupName ARMLBDemoQuickStart `
    -TemplateFile 'https://raw.githubusercontent.com/Azure/azure-quickstart-templates/master/201-2-vms-internal-load-balancer/azuredeploy.json' `
    -TemplateParameterFile $TemplateParameterFile

# Clean up demo
Remove-AzResourceGroup -Name ARMLBDemoQuickStart  -Force


# Option 3: Write template from scratch. Editors such as VS Code provides an extension for ARM Templates which provides Intellisense.
